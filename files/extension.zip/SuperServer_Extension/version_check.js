async function checkForExtensionUpdates() {
    const CURRENT_VERSION = "2.0";
    const VERSION_URL = "https://github.com/vadymhusarovv-stack/Super_Server_Site/tree/main/files/version.json";

    try {
        const response = await fetch(VERSION_URL);
        const data = await response.json();

        if (data.version !== CURRENT_VERSION) {
            const motdBox = document.getElementById("motd");
            if (motdBox) {
                motdBox.innerHTML = `
                    <div style="border: 1px solid #ff3366; background-color: #1a050b; padding: 8px; color: #ff3366; text-align: center; border-radius: 4px; margin-top: 10px;">
                        ⚠️ <strong>ОНОВЛЕННЯ v${data.version}!</strong><br>
                        <a href="${data.download_url}" target="_blank" style="color: #00ffcc; text-decoration: underline; font-weight: bold; display: inline-block; margin-top: 4px;">Завантажити ZIP</a>
                    </div>
                `;
            }
        }
    } catch (err) {
        console.log("Не вдалося перевірити оновлення розширення:", err);
    }
}

checkForExtensionUpdates();