// Слухаємо запити від нашого поп-ап віконця
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "checkOnline") {
        // Фоновий скрипт робить запит без жодних CORS-блокувань браузера!
        fetch(`https://mcsrvstat.us{request.ip}`)
            .then(response => response.json())
            .then(data => sendResponse({ success: true, data: data }))
            .catch(err => sendResponse({ success: false, error: err.message }));
        
        return true; // Кажемо Chrome, що відповідь буде асинхронною
    }
});
