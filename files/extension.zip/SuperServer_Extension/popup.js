document.addEventListener("DOMContentLoaded", () => {
    const dot = document.getElementById("dot");
    const statusText = document.getElementById("status-text");
    const motdBox = document.getElementById("motd");

    // АВТОНОМНИЙ РЕЖИМ: Виводимо лорний статус без запитів в інтернет!
    // Коли ввімкнеш сервер восени - ми просто повернемо мережевий код назад.
    
    dot.style.backgroundColor = "#ffcc00"; // Теплий помаранчевий/жовтий колір аномалії
    dot.style.boxShadow = "0 0 10px #ffcc00";
    statusText.innerText = "ТЕХ.ОБСЛУГОВУВАННЯ";
    statusText.style.color = "#ffcc00";
    
    motdBox.innerHTML = `
        <div style="color: #88c8ff; text-align: left; line-height: 1.4;">
            ⚙️ <strong>Модернізація інфраструктури:</strong> розширення Вікіпедії та перебудова Золотистої зони триває!<br><br>
            🏰 <em>Магічне ядро Paper 1.21.10 перебуває у стані глибокого сну до завершення робіт.</em>
        </div>
    `;
});
