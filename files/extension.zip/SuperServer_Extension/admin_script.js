function activateAdminDashboard() {
    const currentUrl = window.location.href;

    // ЗАХИСТ: Скрипт працює тільки на твоєму локальному сервері або GitHub-сайті
    if (!currentUrl.includes("Super_Server_Site") && !currentUrl.includes("localhost") && !currentUrl.includes("127.0.0.1")) {
        return; 
    }

    // == ФІШКА 1: Проявляємо приховані чорнила на сайті ==
    const hiddenLoreBlock = document.getElementById('arg-hidden-lore');
    if (hiddenLoreBlock) {
        hiddenLoreBlock.style.display = 'block';
    }

    // == ФІШКА 2: Розумні банери-сповіщення ==
    if (!document.getElementById('global-server-notification')) {
        const globalNotice = document.createElement('div');
        globalNotice.id = 'global-server-notification';
        
        let bannerHTML = "";
        if (currentUrl.includes("localhost") || currentUrl.includes("127.0.0.1")) {
            bannerHTML = `
                <div style="background: linear-gradient(90deg, #ff3366, #05070b, #ff3366); color: #fff; text-align: center; padding: 10px; font-family: monospace; font-size: 12px; font-weight: bold; border-bottom: 1px solid #ff3366; box-shadow: 0 2px 10px rgba(255, 51, 102, 0.5); letter-spacing: 1px;">
                    ⚠️ СИНХРОНІЗАЦІЮ СВЯТИЛИЩА ПЕРЕУСТАНОВЛЕНО. ПОТОЧНИЙ СЕКТОР: ЛОКАЛЬНИЙ ТЕСТ 127.0.0.1 ⚠️
                </div>
            `;
        } else {
            bannerHTML = `
                <div style="background: linear-gradient(90deg, #00ffcc, #05070b, #00ffcc); color: #fff; text-align: center; padding: 10px; font-family: monospace; font-size: 12px; font-weight: bold; border-bottom: 1px solid #00ffcc; box-shadow: 0 2px 10px rgba(0, 255, 204, 0.5); letter-spacing: 1px;">
                    🔮 ЗВ'ЯЗОК ІЗ КОРОЛІВСТВОМ СТАБІЛЬНИЙ. ОФІЦІЙНИЙ СУПУТНИК АКТИВНИЙ 🔮
                </div>
            `;
        }
        globalNotice.innerHTML = bannerHTML;
        document.body.insertBefore(globalNotice, document.body.firstChild);
    }

    // == ФІШКА 3: Адмін-блок «Режим Святилища» (Залізобетонне виправлення) ==
    if (!document.getElementById('server-admin-panel')) {
        const adminPanel = document.createElement('div');
        adminPanel.id = 'server-admin-panel';
        
        const imgUrl = chrome.runtime.getURL("logo.png");
        
        adminPanel.innerHTML = `
            <div style="border: 2px dashed #00ffcc; background-color: #05070b; padding: 20px; margin: 30px auto; max-width: 800px; display: flex; align-items: center; justify-content: center; gap: 20px; box-shadow: 0 0 15px #00ffcc; border-radius: 5px; clear: both;">
                <img src="${imgUrl}" style="width: 60px; height: 60px; filter: drop-shadow(0 0 5px #00ffcc);" onerror="this.style.display='none'">
                <div style="text-align: left;">
                    <h3 style="color: #00ffcc; margin: 0 0 5px 0; font-family: monospace; font-size: 18px; text-shadow: 0 0 8px #00ffcc;">🔓 РЕЖИМ СВЯТИЛИЩА АКТИВОВАНО</h3>
                    <p style="color: #a0ff90; font-family: monospace; font-size: 13px; margin: 0;">
                        Вітаємо, Хранителю! Системне розширення виявило підключення. <br>
                        <strong>Шифр наступного рівня:</strong> БЕНДЕР_БЕЗ_КУБИКА_2026
                    </p>
                </div>
            </div>
        `;

        // ДЕТЕКТИВНИЙ ПОШУК МІСЦЯ:
        // 1. Спочатку перевіряємо, чи є на сторінці класичний тег футера (як на твоїй головній)
        const footer = document.querySelector('footer');
        if (footer) {
            // Якщо футер знайшли - вставляємо блок строго ПЕРЕД ним
            footer.parentNode.insertBefore(adminPanel, footer);
            console.log("🔮 Блок вставлено перед футером головної сторінки!");
        } else {
            // 2. Якщо футера немає (це сторінка Docsify Вікі) - шукаємо контейнер контенту
            const docsifyMain = document.getElementById('main') || document.querySelector('.content') || document.body;
            docsifyMain.appendChild(adminPanel);
            console.log("🔮 Блок додано в кінець Docsify-контенту Вікі!");
        }
    }
}

// Запускаємо перевірку через 1.5 секунди
setTimeout(activateAdminDashboard, 1500);
